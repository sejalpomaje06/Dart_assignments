void main(){
	int num=30;
	if(num>=30 && num<=50)
		print("Number is in correct range");
	else
		print("Invalid Range");
}
