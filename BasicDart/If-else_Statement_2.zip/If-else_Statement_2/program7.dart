void main(){
	int noOfPersons=3;
	if(noOfPersons<=8)
		print("You can enter the lift");
	else
		print("You can't entre the lift");
}
