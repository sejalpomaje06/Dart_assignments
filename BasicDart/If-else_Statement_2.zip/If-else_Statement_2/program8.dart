void main(){
	String vehicle="Bike";
	if(vehicle=="Scooter")
		print("Go to parking 1");
	else if(vehicle=="Bike")
		print("Go to parking 2");
}
