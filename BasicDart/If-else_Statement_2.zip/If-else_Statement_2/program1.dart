void main(){
	int ram=4;
	if(ram<4){
		print("Can't run a project");
	}else
		print("Can run a flutter project");
}
