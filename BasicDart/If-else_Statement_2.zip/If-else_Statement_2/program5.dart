void main(){
	int num=14;
	if(num%3==2)
		print("Reminde is equal to 2");
	else
		print("Reminder is less than 2");
}
