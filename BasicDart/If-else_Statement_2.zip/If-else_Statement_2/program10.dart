void main(){
	double percnt=80;
	double cgpa=7.7;
	if(percnt>=70.0 && cgpa>=7.0)
		print("You are eligible");
	else
		print("You are not eligible");
}
