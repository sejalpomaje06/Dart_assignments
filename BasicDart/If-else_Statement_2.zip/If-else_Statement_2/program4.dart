void main(){
	int num=18;
	if(num>=16 && num%2==0)
		print("Correct Number");
	else
		print("Incorrect Number");
}
