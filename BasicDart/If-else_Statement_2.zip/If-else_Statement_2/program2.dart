void main(){
	int num=17;
	if(num==1){
		print("Violet");
	}
	else if(num==2)
		print("Indigo");
	else if(num==3)
		print("Blue");
	else if(num==4)
		print("Green");
	else if(num==5)
		print("Yellow");
	else if(num==6)
		print("Orange");
	else if(num==7)
		print("Red");
	else
		print("Invalid Index");
	
}
