void main(){
	for(int i=100;i<110;i++){
		print(i);
	}
}
