void main(){
	for(int i=1;i<=100;i++){
		print(i);
	}
}
