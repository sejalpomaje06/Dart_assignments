void main(){
	for(int i=100;i>=1;i--){
		print(i);
	}
}
