void main(){
	int num=12;
	for(int i=10;i>=1;i--){
		print(num*i);
	}
}
