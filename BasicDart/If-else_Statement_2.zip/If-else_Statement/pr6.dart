void main(){
	int x=4;
	if(x==0)
		print("Zero");
	else if(x==1)
		print("One");
	else if(x==2)
		print("Two");
	else if(x==3)
		print("Three");
	else if(x==4)
		print("Four");
	else if(x==5)
		print("Five");
	else
		print("Num is greater than 5");
}
