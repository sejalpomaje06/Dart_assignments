void main(){
	int x=1;
	if(x==1){
		print("Please pay 2000 Rupees");
	}else if(x==2){
		print("Please pay 3000 Rupees");
	}else if(x==3){
		print("Please pay 7000 Rupees");		
	}else
		print("Please pay 2500 Rupees");		
}
