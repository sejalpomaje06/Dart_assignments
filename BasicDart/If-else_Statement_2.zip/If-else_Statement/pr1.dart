void main(){
	var x=10;
	if(x%2==0){
		print("$x is an even");
	}else{
		print("$x is an odd");
	}
}
