//print no of days in that months
