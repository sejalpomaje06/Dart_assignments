void main(){
	int age=8;
	if(age>=18){
		print("You can cast a vote");
	}else
		print("You can't cast a vote");
}
