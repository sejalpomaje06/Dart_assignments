void main(){
	var x=15;
	if(x<10){
		print("$x is less than 10");
	}else
		print("$x is greater than 10");
}
