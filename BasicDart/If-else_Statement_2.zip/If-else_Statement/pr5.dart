void main(){
	var c="D";
	if(c=="A"||c=="E"||c=="I"||c=="O"||c=="U"){
		print("$c is vowel");
	}else
		print("$c is consonant");
}
