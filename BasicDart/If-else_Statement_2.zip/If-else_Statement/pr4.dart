void main(){
	var x=-5;
	if(x<0){
		print("$x is negative number");
	}else
		print("$x is positive number");
		
}
