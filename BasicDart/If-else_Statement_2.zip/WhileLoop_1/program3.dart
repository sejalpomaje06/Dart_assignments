void main(){
	int num=9;
	while(num>=0){
		print(num);
		num--;
	}
}
