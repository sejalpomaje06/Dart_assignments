void main(){
	int start=20;
	int end=10;
	while(start>=end){
		if(start%2==1){
			print(start*start);
		}
		start--;
	}
}
