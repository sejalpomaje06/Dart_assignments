void main(){
	int i=1;
	int num=4;
	while(i<=10){
		print(i*num);
		i++;
	}
}
