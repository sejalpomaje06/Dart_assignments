void main(){
	int sum=0;
	int num=12;
	for(int i=1;i<=10;i++){
		int mul=i*num;
		sum=sum+mul;
	}
	print(sum);
}
