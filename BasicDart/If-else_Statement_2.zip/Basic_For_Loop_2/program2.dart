void main(){
	for(int i=63;i<=123;i++){
		if(i%9==0)
			print(i);
	}
}
