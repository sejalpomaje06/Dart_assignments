void main(){
	for(int i=31;i<=55;i++){
		print(i);
	}
}
