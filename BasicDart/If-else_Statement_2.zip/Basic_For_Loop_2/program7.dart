void main(){
	for(int i=20;i<=60;i++){
		if(i%7==0)
			print(i*i*i);
	}
	
}
