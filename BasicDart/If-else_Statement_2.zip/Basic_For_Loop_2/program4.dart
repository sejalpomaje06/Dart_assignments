void main(){
	
	for(int i=100;i<=120;i++){
		print(i*i);
	}
}
